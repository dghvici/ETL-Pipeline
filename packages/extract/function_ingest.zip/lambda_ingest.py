

def lambda_handler_ingest():
    pass