# import boto3
# import json

def lambda_handler_ingest(event, context):
            # s3_client = boto3.client("s3")
            # body = json.dumps("requirements.txt")
            # key = "random_file"
            # bucket = "lullymore-west-ingested"
            # s3_client.put_object(Bucket=bucket, Key=key, Body=body)
    # placeholder for the purpose of the CICD-pipeline/Terraform
    # do not change lambda handler name --> linked to tf lamda handler resource
    # manually tested
    return True
