

def lambda_handler_transform():
    # placeholder for the purpose of the CICD pipeline
    # do not change lambda handler name --> linked to tf lamda handler resource
    return True
