

def lambda_handler_load():
    # placeholder for the purpose of the CICD-pipeline/Terraform
    # do not change lambda handler name --> linked to tf lamda handler resource

    pass