

def lambda_handler_load():
    pass